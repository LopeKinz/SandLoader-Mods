#!/usr/bin/env node
'use strict'

const net = require('net')
const readline = require('readline')

const HOST = '127.0.0.1'
const PORT = Number(process.env.SANDUSTRY_MCP_PORT || 47651)
const SERVER_INFO = { name: 'sandustry-mcp-debug', version: '2.3.0' }
const SUPPORTED = ['2025-06-18', '2025-03-26', '2024-11-05']
let seq = 0

const ro = { readOnlyHint: true, destructiveHint: false }
const rw = { readOnlyHint: false, destructiveHint: true }

const tools = [
  t('sandustry_status','Bridge, Electron, SandLoader and game readiness.',{},ro),
  t('list_windows','List Electron windows and identify the game window.',{},ro),
  t('open_devtools','Open Chromium DevTools for the Sandustry game window.',{
    mode:{type:'string',enum:['detach','right','bottom','undocked'],default:'detach'},
    activate:{type:'boolean',default:true}
  },rw),
  t('close_devtools','Close Chromium DevTools for the game window.',{},rw),
  t('reload_game_window','Reload the game renderer. Useful after UI/runtime failures.',{
    ignoreCache:{type:'boolean',default:false}
  },rw),
  t('capture_game_screenshot','Capture the current Sandustry game window as PNG.',{},ro),

  t('get_console_logs','Read buffered renderer console messages, load errors, crashes and bridge logs.',{
    limit:{type:'integer',minimum:1,maximum:1000,default:200},
    sinceId:{type:'integer',minimum:0,default:0},
    kind:{type:'string'},
    level:{type:'string'}
  },ro),
  t('clear_console_logs','Clear the MCP debug bridge console/error buffer.',{},rw),
  t('list_sandloader_logs','List SandLoader log files from the current userData directory.',{},ro),
  t('read_sandloader_log_tail','Read the tail of a SandLoader log file. Omitting file selects the newest.',{
    file:{type:'string'},
    maxBytes:{type:'integer',minimum:1024,maximum:1048576,default:131072}
  },ro),

  t('renderer_eval','Execute JavaScript inside the live Sandustry renderer and return a JSON-safe result. Full debug escape hatch.',{
    code:{type:'string',minLength:1},
    maxDepth:{type:'integer',minimum:0,maximum:6,default:4},
    requireReady:{type:'boolean',default:true}
  },rw,['code']),
  t('inspect_dom','Inspect matching DOM nodes, text, rectangles and optionally outerHTML.',{
    selector:{type:'string',default:'body'},
    limit:{type:'integer',minimum:1,maximum:100,default:20},
    html:{type:'boolean',default:false}
  },ro),
  t('performance_snapshot','Read DOM/JS heap/performance information from the renderer.',{},ro),
  t('cdp_attach','Attach Chrome DevTools Protocol 1.3 to the Sandustry renderer.',{},rw),
  t('cdp_detach','Detach Chrome DevTools Protocol from the Sandustry renderer.',{},rw),
  t('cdp_command','Send any Chrome DevTools Protocol command. Use this for Network, Runtime, DOM, Debugger, Profiler, Performance and more.',{
    method:{type:'string',minLength:1},
    params:{type:'object',default:{}},
    sessionId:{type:'string'}
  },rw,['method']),

  t('state_keys','List keys at a dotted path under SMLN.state.',{
    path:{type:'string',default:''}
  },ro),
  t('inspect_state','Read a depth-limited JSON-safe snapshot from SMLN.state.',{
    path:{type:'string',default:''},
    maxDepth:{type:'integer',minimum:0,maximum:6,default:3}
  },ro),

  t('list_game_api','List namespaces exposed through SMLN.game.',{},ro),
  t('list_api_members','List members and types in one SMLN.game namespace.',{
    namespace:{type:'string',minLength:1}
  },ro,['namespace']),
  t('describe_api_namespace','Inspect values and function signatures/source snippets in one game API namespace.',{
    namespace:{type:'string',minLength:1}
  },ro,['namespace']),
  t('call_game_api','Call a named SMLN.game method. Methods are state-first by default.',{
    namespace:{type:'string',minLength:1},
    method:{type:'string',minLength:1},
    args:{type:'array',default:[]},
    stateFirst:{type:'boolean',default:true}
  },rw,['namespace','method']),

  t('sandloader_rpc','Call an arbitrary existing SMLN.callMain action for deep SandLoader diagnostics/management.',{
    action:{type:'string',minLength:1},
    payload:{type:'object',default:{}}
  },rw,['action']),
  t('get_sandloader_problems','Read SandLoader Problems, including survived mod/patch errors.',{},ro),
  t('get_sandloader_mods','Read SandLoader mod summaries, states and capability information.',{},ro),
  t('get_loader_state','Read SandLoader version/game/watch state.',{},ro),

  t('run_console_command','Run any command registered in the SandLoader in-game developer console.',{
    command:{type:'string',minLength:1},
    args:{type:'array',items:{type:'string'},default:[]}
  },rw,['command']),

  t('get_player_position','Read current player position.',{},ro),
  t('set_player_position','Move player to an absolute position.',{
    x:{type:'number'},y:{type:'number'}
  },rw,['x','y']),
  t('get_cell_id','Read world cell id.',{
    x:{type:'integer'},y:{type:'integer'}
  },ro,['x','y']),
  t('create_element','Create an element by numeric id.',{
    x:{type:'integer'},y:{type:'integer'},id:{type:'integer'},options:{type:'object',default:{}}
  },rw,['x','y','id']),
  t('remove_element','Remove element at a cell.',{
    x:{type:'integer'},y:{type:'integer'}
  },rw,['x','y']),
  t('create_terrain','Create terrain by name.',{
    x:{type:'integer'},y:{type:'integer'},name:{type:'string',minLength:1}
  },rw,['x','y','name']),
  t('remove_terrain','Remove terrain at a cell.',{
    x:{type:'integer'},y:{type:'integer'}
  },rw,['x','y']),

  t('get_host_paths','List the Sandustry/SandLoader/mod roots that file diagnostics are allowed to inspect.',{},ro),
  t('list_scoped_dir','List files under an allowed Sandustry/SandLoader root.',{
    root:{type:'string',minLength:1},path:{type:'string',default:'.'},depth:{type:'integer',minimum:0,maximum:4,default:0}
  },ro,['root']),
  t('read_scoped_file','Read a UTF-8 file under an allowed root.',{
    root:{type:'string',minLength:1},path:{type:'string',minLength:1},maxBytes:{type:'integer',minimum:1024,maximum:2097152,default:262144}
  },ro,['root','path']),
  t('stat_scoped_path','Stat a file or directory under an allowed root.',{
    root:{type:'string',minLength:1},path:{type:'string',default:'.'}
  },ro,['root']),
  t('hash_scoped_file','Calculate SHA-256/SHA-1 of an allowed game/mod file.',{
    root:{type:'string',minLength:1},path:{type:'string',minLength:1},algorithm:{type:'string',enum:['sha256','sha1'],default:'sha256'}
  },ro,['root','path']),
  t('search_scoped_text','Recursively search text files under an allowed root.',{
    root:{type:'string',minLength:1},path:{type:'string',default:'.'},query:{type:'string',minLength:1},
    caseSensitive:{type:'boolean',default:false},maxFiles:{type:'integer',minimum:1,maximum:2000,default:500},
    maxMatches:{type:'integer',minimum:1,maximum:2000,default:200}
  },ro,['root','query']),

  t('system_metrics','Read Node/Electron process metrics plus OS memory/CPU information.',{},ro),
  t('webcontents_info','Read game webContents state such as URL, zoom, frame rate and process ID.',{},ro),

  t('dom_computed_style','Read computed CSS styles for one selector.',{
    selector:{type:'string',minLength:1},properties:{type:'array',items:{type:'string'},default:[]}
  },ro,['selector']),
  t('dom_click','Click a DOM element. Useful for reproducing UI bugs.',{
    selector:{type:'string',minLength:1}
  },rw,['selector']),
  t('dom_focus','Focus a DOM element.',{selector:{type:'string',minLength:1}},rw,['selector']),
  t('dom_input','Set an input value and dispatch input/change events.',{
    selector:{type:'string',minLength:1},value:{type:'string'}
  },rw,['selector','value']),
  t('dom_attributes','Read all attributes from the first matching DOM node.',{
    selector:{type:'string',minLength:1}
  },ro,['selector']),

  t('list_console_commands','List all SandLoader developer-console commands with usage metadata.',{},ro),
  t('worker_messaging_stats','Read SandLoader simulation/manager worker targets and messaging counters.',{},ro),
  t('send_worker_message','Send a SandLoader message to all simulation worker threads.',{
    modID:{type:'string',default:'sandustry-mcp'},channel:{type:'string',minLength:1},args:{type:'array',default:[]}
  },rw,['channel']),
  t('send_manager_message','Send a SandLoader message to the manager worker.',{
    modID:{type:'string',default:'sandustry-mcp'},channel:{type:'string',minLength:1},args:{type:'array',default:[]}
  },rw,['channel']),

  t('list_enum_tables','List SMLN enum/reference tables, or keys/values inside a table.',{
    table:{type:'string'}
  },ro),
  t('get_enum_value','Read one value from an SMLN enum/reference table.',{
    table:{type:'string',minLength:1},key:{type:['string','number']}
  },ro,['table','key']),

  t('capture_state_snapshot','Capture a sanitized in-memory snapshot of SMLN.state or one dotted path.',{
    label:{type:'string'},path:{type:'string',default:''},maxDepth:{type:'integer',minimum:0,maximum:8,default:5}
  },ro),
  t('list_state_snapshots','List stored state snapshots.',{},ro),
  t('get_state_snapshot','Read one stored state snapshot.',{id:{type:'string',minLength:1}},ro,['id']),
  t('diff_state_snapshots','Deep-diff two stored state snapshots.',{
    before:{type:'string',minLength:1},after:{type:'string',minLength:1},limit:{type:'integer',minimum:1,maximum:5000,default:500}
  },ro,['before','after']),
  t('clear_state_snapshots','Clear stored state snapshots.',{},rw),

  t('start_game_event_probe','Start recording a named FH game event into a bounded buffer.',{
    event:{type:'string',minLength:1},limit:{type:'integer',minimum:1,maximum:5000,default:500}
  },rw,['event']),
  t('get_game_event_probe','Read recorded events from a probe and optionally clear its buffer.',{
    id:{type:'string',minLength:1},clear:{type:'boolean',default:false}
  },ro,['id']),
  t('stop_game_event_probe','Stop and remove an event probe.',{id:{type:'string',minLength:1}},rw,['id']),
  t('list_game_event_probes','List active game event probes.',{},ro),

  t('get_mod_details','Read one SandLoader mod details/capabilities/approval/problems record.',{
    id:{type:'string',minLength:1}
  },ro,['id']),
  t('get_mod_config','Read one mod config schema and current values.',{id:{type:'string',minLength:1}},ro,['id']),
  t('set_mod_config','Set one SandLoader mod config value through the normal validator.',{
    id:{type:'string',minLength:1},key:{type:'string',minLength:1},value:{}
  },rw,['id','key','value']),
  t('reset_mod_config','Reset one key or the complete mod config to defaults.',{
    id:{type:'string',minLength:1},key:{type:'string'}
  },rw,['id']),
  t('rescan_patch_anchors','Force SandLoader to re-scan and auto-heal patch anchors.',{},rw),
  t('reload_mods_plan','Ask SandLoader what kind of reload is required.',{},ro),
  t('reload_mods','Apply a SandLoader mod reload.',{},rw),
  t('reload_one_mod','Reload one mod or report the required reload stage.',{
    id:{type:'string',minLength:1}
  },rw,['id']),

  t('state_array_page','Page through a large array in SMLN.state and return compact primitive fields such as IDs, types and coordinates instead of [Object].',{
    path:{type:'string',minLength:1},offset:{type:'integer',minimum:0,default:0},limit:{type:'integer',minimum:1,maximum:500,default:50}
  },ro,['path']),
  t('state_array_item','Read one full item from an array in SMLN.state by index.',{
    path:{type:'string',minLength:1},index:{type:'integer',minimum:0},maxDepth:{type:'integer',minimum:0,maximum:10,default:8}
  },ro,['path','index']),
  t('search_state_array','Search primitive fields in a large SMLN.state array, useful for IDs, types, names and coordinates.',{
    path:{type:'string',minLength:1},query:{type:'string',minLength:1},caseSensitive:{type:'boolean',default:false},maxResults:{type:'integer',minimum:1,maximum:1000,default:100}
  },ro,['path','query'])
]

function t(name, description, properties, annotations, required) {
  return {
    name, description,
    inputSchema: {
      type:'object',
      properties: properties || {},
      required: required || [],
      additionalProperties:false
    },
    annotations
  }
}

function bridge(method, params) {
  return new Promise((resolve, reject) => {
    const id = ++seq
    const socket = net.createConnection({host:HOST,port:PORT})
    let buf = '', done = false
    const timer = setTimeout(() => finish(reject, new Error('Sandustry bridge timeout')), 30000)

    function finish(fn, value) {
      if (done) return
      done = true
      clearTimeout(timer)
      socket.destroy()
      fn(value)
    }

    socket.setEncoding('utf8')
    socket.on('connect', () => socket.write(JSON.stringify({id,method,params:params||{}})+'\n'))
    socket.on('data', (chunk) => {
      buf += chunk
      let n
      while ((n = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0,n).trim()
        buf = buf.slice(n+1)
        if (!line) continue
        let msg
        try { msg = JSON.parse(line) } catch (_) { continue }
        if (msg.id !== id) continue
        if (msg.ok) finish(resolve,msg.result)
        else finish(reject,new Error(msg.error || 'Sandustry bridge error'))
      }
    })
    socket.on('error', (e) => {
      const msg = e && e.code === 'ECONNREFUSED'
        ? `Sandustry MCP Debug Bridge is not running on ${HOST}:${PORT}. Start Sandustry with the mod enabled and approved.`
        : String(e && e.message || e)
      finish(reject,new Error(msg))
    })
  })
}

function normal(value) {
  const text = typeof value === 'string' ? value : JSON.stringify(value,null,2)
  const result = {content:[{type:'text',text}]}
  if (value && typeof value === 'object' && !Array.isArray(value)) result.structuredContent = value
  return result
}
function failure(e) {
  return {content:[{type:'text',text:String(e && e.message || e)}],isError:true}
}

async function call(name,a) {
  const map = {
    sandustry_status:['status'],
    list_windows:['listWindows'],
    open_devtools:['openDevTools'],
    close_devtools:['closeDevTools'],
    reload_game_window:['reloadWindow'],
    capture_game_screenshot:['captureScreenshot'],
    get_console_logs:['getConsoleLogs'],
    clear_console_logs:['clearConsoleLogs'],
    list_sandloader_logs:['listLogFiles'],
    read_sandloader_log_tail:['readLogTail'],
    renderer_eval:['rendererEval'],
    inspect_dom:['inspectDom'],
    performance_snapshot:['performanceSnapshot'],
    cdp_attach:['cdpAttach'],
    cdp_detach:['cdpDetach'],
    cdp_command:['cdpCommand'],
    state_keys:['stateKeys'],
    inspect_state:['inspectState'],
    list_game_api:['listNamespaces'],
    list_api_members:['listMethods'],
    describe_api_namespace:['describeApi'],
    call_game_api:['callGameApi'],
    sandloader_rpc:['sandloaderRpc'],
    get_sandloader_problems:['getProblems'],
    get_sandloader_mods:['getMods'],
    get_loader_state:['getLoaderState'],
    run_console_command:['runConsoleCommand'],
    get_player_position:['playerGetPosition'],
    set_player_position:['playerSetPosition'],
    get_cell_id:['getCellId'],
    create_element:['createElement'],
    remove_element:['removeElement'],
    create_terrain:['createTerrain'],
    remove_terrain:['removeTerrain'],
    get_host_paths:['hostPaths'],
    list_scoped_dir:['listScopedDir'],
    read_scoped_file:['readScopedFile'],
    stat_scoped_path:['statScopedPath'],
    hash_scoped_file:['hashScopedFile'],
    search_scoped_text:['searchScopedText'],
    system_metrics:['systemMetrics'],
    webcontents_info:['webContentsInfo'],
    dom_computed_style:['domComputedStyle'],
    dom_click:['domClick'],
    dom_focus:['domFocus'],
    dom_input:['domInput'],
    dom_attributes:['domAttributes'],
    list_console_commands:['listConsoleCommands'],
    worker_messaging_stats:['messagingStats'],
    send_worker_message:['sendWorkerMessage'],
    send_manager_message:['sendManagerMessage'],
    list_enum_tables:['enumKeys'],
    get_enum_value:['enumGet'],
    capture_state_snapshot:['captureStateSnapshot'],
    list_state_snapshots:['listStateSnapshots'],
    get_state_snapshot:['getStateSnapshot'],
    diff_state_snapshots:['diffStateSnapshots'],
    clear_state_snapshots:['clearStateSnapshots'],
    start_game_event_probe:['startEventProbe'],
    get_game_event_probe:['getEventProbe'],
    stop_game_event_probe:['stopEventProbe'],
    list_game_event_probes:['listEventProbes'],
    get_mod_details:['getModDetails'],
    get_mod_config:['getModConfig'],
    set_mod_config:['setModConfig'],
    reset_mod_config:['resetModConfig'],
    rescan_patch_anchors:['rescanAnchors'],
    reload_mods_plan:['reloadModsPlan'],
    reload_mods:['reloadModsApply'],
    reload_one_mod:['reloadOneMod'],
    state_array_page:['stateArrayPage'],
    state_array_item:['stateArrayItem'],
    search_state_array:['searchStateArray']
  }
  if (!map[name]) throw new Error('Unknown tool: '+name)
  const v = await bridge(map[name][0],a)
  if (name === 'capture_game_screenshot') {
    return {
      content:[
        {type:'image',data:v.data,mimeType:v.mimeType},
        {type:'text',text:JSON.stringify({size:v.size},null,2)}
      ]
    }
  }
  return normal(v)
}

async function handle(req) {
  if (!req || req.jsonrpc !== '2.0' || typeof req.method !== 'string') {
    return req && req.id != null ? {jsonrpc:'2.0',id:req.id,error:{code:-32600,message:'Invalid Request'}} : null
  }
  if (req.method === 'initialize') {
    const requested = req.params && req.params.protocolVersion
    const protocolVersion = SUPPORTED.includes(requested) ? requested : SUPPORTED[0]
    return {jsonrpc:'2.0',id:req.id,result:{
      protocolVersion,
      capabilities:{tools:{listChanged:false}},
      serverInfo:SERVER_INFO,
      instructions:'Sandustry live debugging through SandLoader. renderer_eval and sandloader_rpc are full-power local debug escape hatches.'
    }}
  }
  if (req.method === 'notifications/initialized' || req.method === 'notifications/cancelled') return null
  if (req.method === 'ping') return {jsonrpc:'2.0',id:req.id,result:{}}
  if (req.method === 'tools/list') return {jsonrpc:'2.0',id:req.id,result:{tools}}
  if (req.method === 'tools/call') {
    try {
      return {jsonrpc:'2.0',id:req.id,result:await call(req.params && req.params.name,(req.params && req.params.arguments)||{})}
    } catch (e) {
      return {jsonrpc:'2.0',id:req.id,result:failure(e)}
    }
  }
  if (req.id == null) return null
  return {jsonrpc:'2.0',id:req.id,error:{code:-32601,message:'Method not found: '+req.method}}
}

if (process.argv.includes('--print-tools')) {
  process.stdout.write(JSON.stringify(tools, null, 2))
  process.exit(0)
}

const rl = readline.createInterface({input:process.stdin,crlfDelay:Infinity,terminal:false})
rl.on('line', async (line) => {
  line=line.trim()
  if (!line) return
  let req
  try { req=JSON.parse(line) }
  catch (_) { process.stdout.write(JSON.stringify({jsonrpc:'2.0',id:null,error:{code:-32700,message:'Parse error'}})+'\n'); return }
  try {
    const res=await handle(req)
    if (res) process.stdout.write(JSON.stringify(res)+'\n')
  } catch (e) {
    if (req && req.id != null) process.stdout.write(JSON.stringify({jsonrpc:'2.0',id:req.id,error:{code:-32603,message:String(e && e.message || e)}})+'\n')
  }
})
