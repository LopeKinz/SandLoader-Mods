'use strict'

const net = require('net')
const http = require('http')
const fs = require('fs')
const path = require('path')
const os = require('os')
const crypto = require('crypto')
const { app, BrowserWindow } = require('electron')

const HOST = '127.0.0.1'
const PORT = Number(process.env.SANDUSTRY_MCP_PORT || 47651)
const HTTP_PORT = Number(process.env.SANDUSTRY_MCP_HTTP_PORT || 47652)
const MAX_LINE = 2 * 1024 * 1024
const MAX_LOGS = 2000

let server = null
let httpServer = null
let scopedLogger = null
let hostApi = null
let modInfo = null
let smlnInfo = null
let seq = 0
const logs = []
const stateSnapshots = new Map()
let snapshotSeq = 0
const hooked = new WeakSet()
const cdpHooked = new WeakSet()

function addLog(kind, data) {
  const entry = {
    id: ++seq,
    ts: new Date().toISOString(),
    kind,
    ...data
  }
  logs.push(entry)
  if (logs.length > MAX_LOGS) logs.splice(0, logs.length - MAX_LOGS)
  return entry
}

function log(level, message) {
  addLog('bridge', { level, message: String(message) })
  try {
    if (scopedLogger && typeof scopedLogger[level] === 'function') scopedLogger[level](message)
    else console.error('[sandustry-mcp] ' + message)
  } catch (_) {}
}

function hookWindow(win) {
  if (!win || win.isDestroyed() || hooked.has(win)) return
  hooked.add(win)
  const wc = win.webContents
  const wid = win.id

  wc.on('console-message', (_event, level, message, line, sourceId) => {
    addLog('console', { windowId: wid, level, message, line, sourceId })
  })
  wc.on('did-fail-load', (_event, errorCode, errorDescription, validatedURL, isMainFrame) => {
    addLog('did-fail-load', { windowId: wid, errorCode, errorDescription, validatedURL, isMainFrame })
  })
  wc.on('render-process-gone', (_event, details) => {
    addLog('render-process-gone', { windowId: wid, details })
  })
  wc.on('unresponsive', () => addLog('unresponsive', { windowId: wid }))
  wc.on('responsive', () => addLog('responsive', { windowId: wid }))
  wc.on('preload-error', (_event, preloadPath, error) => {
    addLog('preload-error', { windowId: wid, preloadPath, error: String(error && error.stack || error) })
  })
  wc.on('did-finish-load', () => addLog('did-finish-load', { windowId: wid, url: wc.getURL() }))
}

function hookAllWindows() {
  for (const win of BrowserWindow.getAllWindows()) hookWindow(win)
}

async function findGameWindow() {
  hookAllWindows()
  const windows = BrowserWindow.getAllWindows().filter((w) => w && !w.isDestroyed())
  for (const win of windows) {
    try {
      const hasSmln = await win.webContents.executeJavaScript(
        'Boolean(globalThis.SMLN && globalThis.SMLN.version)', true
      )
      if (hasSmln) return win
    } catch (_) {}
  }
  return null
}

function windowSummary(win) {
  const wc = win.webContents
  return {
    id: win.id,
    title: win.getTitle(),
    visible: win.isVisible(),
    focused: win.isFocused(),
    minimized: win.isMinimized(),
    maximized: win.isMaximized(),
    destroyed: win.isDestroyed(),
    url: wc.getURL(),
    devToolsOpened: wc.isDevToolsOpened(),
    loading: wc.isLoading(),
    webContentsId: wc.id,
    processId: typeof wc.getOSProcessId === 'function' ? wc.getOSProcessId() : null
  }
}

function hookCdp(wc, windowId) {
  if (!wc || cdpHooked.has(wc)) return
  cdpHooked.add(wc)
  wc.debugger.on('message', (_event, method, params, sessionId) => {
    addLog('cdp', { windowId, method, params, sessionId: sessionId || null })
  })
  wc.debugger.on('detach', (_event, reason) => {
    addLog('cdp-detach', { windowId, reason })
  })
}

async function ensureCdp() {
  const win = await findGameWindow()
  if (!win) throw new Error('game window not found')
  const wc = win.webContents
  hookCdp(wc, win.id)
  if (!wc.debugger.isAttached()) wc.debugger.attach('1.3')
  return { win, wc }
}

const SANITIZER = String.raw`
function __mcpSanitize(value, depth, seen) {
  depth = depth == null ? 3 : depth
  seen = seen || new WeakSet()
  if (value == null || typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') return value
  if (typeof value === 'bigint') return String(value)
  if (typeof value === 'symbol') return String(value)
  if (typeof value === 'function') return '[Function ' + (value.name || 'anonymous') + ']'
  if (typeof value !== 'object') return String(value)
  if (seen.has(value)) return '[Circular]'
  if (depth <= 0) {
    if (Array.isArray(value)) return '[Array(' + value.length + ')]'
    return '[' + ((value.constructor && value.constructor.name) || 'Object') + ']'
  }
  seen.add(value)
  try {
    if (value instanceof Error) return {name:value.name,message:value.message,stack:value.stack}
    if (ArrayBuffer.isView(value)) return '[' + value.constructor.name + '(' + value.length + ')]'
    if (value instanceof ArrayBuffer) return '[ArrayBuffer(' + value.byteLength + ')]'
    if (Array.isArray(value)) {
      var arr = value.slice(0, 100).map(function (x) { return __mcpSanitize(x, depth - 1, seen) })
      if (value.length > 100) arr.push('[+' + (value.length - 100) + ' more]')
      return arr
    }
    var out = {}
    var all = Object.keys(value)
    var keys = all.slice(0, 150)
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i]
      try { out[k] = __mcpSanitize(value[k], depth - 1, seen) }
      catch (e) { out[k] = '[unreadable: ' + (e && e.message || e) + ']' }
    }
    if (all.length > keys.length) out.__truncated__ = all.length - keys.length
    return out
  } finally {
    seen.delete(value)
  }
}
`

async function inGame(body, opts = {}) {
  const win = await findGameWindow()
  if (!win) throw new Error('Sandustry game window not found. Start Sandustry with SandLoader first.')
  const ready = opts.ready !== false
  const source = `(async function () {
    ${SANITIZER}
    const S = globalThis.SMLN
    if (!S) throw new Error('SandLoader renderer runtime is not available')
    ${ready ? "if (!S.game || !S.state) throw new Error('Game API is not ready; load into a game/save first')" : ""}
    ${body}
  })()`
  return win.webContents.executeJavaScript(source, true)
}

function num(value, name) {
  const n = Number(value)
  if (!Number.isFinite(n)) throw new Error(name + ' must be a finite number')
  return n
}
function int(value, name) {
  const n = Number(value)
  if (!Number.isInteger(n)) throw new Error(name + ' must be an integer')
  return n
}
function safeName(value, name) {
  if (typeof value !== 'string' || !value || value.length > 256) throw new Error(name + ' must be a non-empty string')
  if (value === '__proto__' || value === 'prototype' || value === 'constructor') throw new Error(name + ' is not allowed')
  return value
}


function safeJsonClone(value) {
  return JSON.parse(JSON.stringify(value))
}

function scopedRoots() {
  const roots = []
  function add(name, value) {
    if (typeof value !== 'string' || !value) return
    try {
      const resolved = path.resolve(value)
      if (!roots.some((r) => r.path === resolved)) roots.push({ name, path: resolved })
    } catch (_) {}
  }

  if (modInfo && modInfo.dir) add('mod', modInfo.dir)
  const hp = hostApi && hostApi.paths
  if (hp && typeof hp === 'object') {
    for (const [k, v] of Object.entries(hp)) add('host.' + k, v)
  }
  const install = smlnInfo && smlnInfo.install
  if (install && typeof install === 'object') {
    for (const [k, v] of Object.entries(install)) {
      if (typeof v !== 'string') continue
      try {
        if (fs.existsSync(v)) {
          const st = fs.statSync(v)
          add('install.' + k, st.isDirectory() ? v : path.dirname(v))
        }
      } catch (_) {}
    }
  }
  add('userData', app.getPath('userData'))
  return roots
}

function resolveScoped(rootName, rel) {
  const roots = scopedRoots()
  const root = roots.find((r) => r.name === rootName)
  if (!root) throw new Error('unknown scoped root: ' + rootName)
  const relative = rel == null || rel === '' ? '.' : String(rel)
  if (relative.includes('\0')) throw new Error('path contains NUL')
  const target = path.resolve(root.path, relative)
  const prefix = root.path.endsWith(path.sep) ? root.path : root.path + path.sep
  if (target !== root.path && !target.startsWith(prefix)) throw new Error('path escapes scoped root')
  return { root, target }
}

function listScoped(rootName, rel, depth) {
  const { root, target } = resolveScoped(rootName, rel)
  const maxDepth = Math.max(0, Math.min(Number(depth) || 0, 4))
  const out = []
  function walk(cur, currentDepth) {
    const entries = fs.readdirSync(cur, { withFileTypes: true })
    for (const e of entries) {
      const full = path.join(cur, e.name)
      let st
      try { st = fs.statSync(full) } catch (_) { continue }
      out.push({
        path: path.relative(root.path, full).split(path.sep).join('/'),
        type: e.isDirectory() ? 'dir' : e.isFile() ? 'file' : 'other',
        size: st.size,
        modified: st.mtime.toISOString()
      })
      if (e.isDirectory() && currentDepth < maxDepth) walk(full, currentDepth + 1)
      if (out.length >= 5000) return
    }
  }
  walk(target, 0)
  return out
}

function readScoped(rootName, rel, maxBytes) {
  const { root, target } = resolveScoped(rootName, rel)
  const st = fs.statSync(target)
  if (!st.isFile()) throw new Error('not a file')
  const cap = Math.max(1024, Math.min(Number(maxBytes) || 262144, 2 * 1024 * 1024))
  const fd = fs.openSync(target, 'r')
  try {
    const size = Math.min(st.size, cap)
    const buf = Buffer.alloc(size)
    fs.readSync(fd, buf, 0, size, 0)
    return {
      root: root.name,
      path: path.relative(root.path, target).split(path.sep).join('/'),
      size: st.size,
      truncated: st.size > cap,
      text: buf.toString('utf8')
    }
  } finally { fs.closeSync(fd) }
}

function searchScoped(rootName, rel, needle, opts) {
  const { root, target } = resolveScoped(rootName, rel)
  const q = String(needle || '')
  if (!q) throw new Error('query is required')
  const maxFiles = Math.max(1, Math.min(Number(opts && opts.maxFiles) || 500, 2000))
  const maxMatches = Math.max(1, Math.min(Number(opts && opts.maxMatches) || 200, 2000))
  const caseSensitive = !!(opts && opts.caseSensitive)
  const wanted = caseSensitive ? q : q.toLowerCase()
  const matches = []
  let scanned = 0

  function walk(cur) {
    if (scanned >= maxFiles || matches.length >= maxMatches) return
    let entries
    try { entries = fs.readdirSync(cur, { withFileTypes: true }) } catch (_) { return }
    for (const e of entries) {
      if (scanned >= maxFiles || matches.length >= maxMatches) break
      const full = path.join(cur, e.name)
      if (e.isDirectory()) { walk(full); continue }
      if (!e.isFile()) continue
      let st
      try { st = fs.statSync(full) } catch (_) { continue }
      if (st.size > 4 * 1024 * 1024) continue
      scanned++
      let text
      try { text = fs.readFileSync(full, 'utf8') } catch (_) { continue }
      const hay = caseSensitive ? text : text.toLowerCase()
      let pos = 0, hit
      while ((hit = hay.indexOf(wanted, pos)) >= 0 && matches.length < maxMatches) {
        const line = text.slice(0, hit).split('\n').length
        const start = Math.max(0, hit - 120)
        const end = Math.min(text.length, hit + q.length + 240)
        matches.push({
          path: path.relative(root.path, full).split(path.sep).join('/'),
          line,
          excerpt: text.slice(start, end)
        })
        pos = hit + Math.max(1, q.length)
      }
    }
  }
  walk(target)
  return { scannedFiles: scanned, matches }
}

function deepDiff(a, b, pathPrefix, out, limit) {
  if (out.length >= limit) return
  if (Object.is(a, b)) return
  const pathHere = pathPrefix || '$'
  const ao = a && typeof a === 'object'
  const bo = b && typeof b === 'object'
  if (!ao || !bo || Array.isArray(a) !== Array.isArray(b)) {
    out.push({ path: pathHere, before: a, after: b })
    return
  }
  const keys = new Set([...Object.keys(a), ...Object.keys(b)])
  for (const key of keys) {
    if (out.length >= limit) break
    const child = pathHere === '$' ? '$.' + key : pathHere + '.' + key
    if (!(key in a)) out.push({ path: child, before: '[missing]', after: b[key] })
    else if (!(key in b)) out.push({ path: child, before: a[key], after: '[missing]' })
    else deepDiff(a[key], b[key], child, out, limit)
  }
}

function logDir() {
  const userData = hostApi && hostApi.paths && hostApi.paths.userData
    ? hostApi.paths.userData
    : app.getPath('userData')
  return path.join(userData, 'smln', 'logs')
}

function listLogFiles() {
  const dir = logDir()
  if (!fs.existsSync(dir)) return []
  return fs.readdirSync(dir, { withFileTypes: true })
    .filter((x) => x.isFile())
    .map((x) => {
      const full = path.join(dir, x.name)
      const st = fs.statSync(full)
      return { name: x.name, size: st.size, modified: st.mtime.toISOString() }
    })
    .sort((a, b) => b.modified.localeCompare(a.modified))
}

function readTail(file, maxBytes) {
  const dir = logDir()
  const files = listLogFiles()
  const name = file || (files[0] && files[0].name)
  if (!name) return { file: null, text: '' }
  if (path.basename(name) !== name) throw new Error('invalid log filename')
  const full = path.join(dir, name)
  if (!fs.existsSync(full)) throw new Error('log file not found: ' + name)
  const stat = fs.statSync(full)
  const bytes = Math.max(1024, Math.min(Number(maxBytes) || 128 * 1024, 1024 * 1024))
  const start = Math.max(0, stat.size - bytes)
  const fd = fs.openSync(full, 'r')
  try {
    const buf = Buffer.alloc(stat.size - start)
    fs.readSync(fd, buf, 0, buf.length, start)
    return { file: name, size: stat.size, offset: start, text: buf.toString('utf8') }
  } finally {
    fs.closeSync(fd)
  }
}

async function handle(method, params) {
  params = params || {}

  switch (method) {
    case 'ping':
      return { pong: true, port: PORT, httpPort: HTTP_PORT, version: '2.3.0' }

    case 'status': {
      const win = await findGameWindow()
      let renderer = null
      if (win) {
        try {
          renderer = await inGame(`
            return {
              sandloader: S.version || null,
              ready: Boolean(S.game && S.state),
              namespaces: S.game ? Object.keys(S.game).length : 0,
              sandkitAvailable: Boolean(S.sandkit),
              href: location.href,
              title: document.title,
              visibility: document.visibilityState
            }
          `, { ready: false })
        } catch (e) {
          renderer = { error: String(e && e.message || e) }
        }
      }
      return {
        bridge: { host: HOST, port: PORT, httpPort: HTTP_PORT, version: '2.3.0' },
        node: process.version,
        electron: process.versions.electron || null,
        chrome: process.versions.chrome || null,
        platform: process.platform,
        arch: process.arch,
        gameWindow: win ? windowSummary(win) : null,
        renderer
      }
    }

    case 'listWindows':
      hookAllWindows()
      return BrowserWindow.getAllWindows().filter((w) => !w.isDestroyed()).map(windowSummary)

    case 'openDevTools': {
      const win = await findGameWindow()
      if (!win) throw new Error('game window not found')
      win.webContents.openDevTools({ mode: params.mode || 'detach', activate: params.activate !== false })
      return { ok: true, opened: true }
    }

    case 'closeDevTools': {
      const win = await findGameWindow()
      if (!win) throw new Error('game window not found')
      win.webContents.closeDevTools()
      return { ok: true, opened: false }
    }

    case 'reloadWindow': {
      const win = await findGameWindow()
      if (!win) throw new Error('game window not found')
      if (params.ignoreCache) win.webContents.reloadIgnoringCache()
      else win.reload()
      return { ok: true, ignoreCache: !!params.ignoreCache }
    }

    case 'captureScreenshot': {
      const win = await findGameWindow()
      if (!win) throw new Error('game window not found')
      const img = await win.webContents.capturePage()
      return {
        mimeType: 'image/png',
        data: img.toPNG().toString('base64'),
        size: img.getSize()
      }
    }

    case 'getConsoleLogs': {
      const limit = Math.max(1, Math.min(int(params.limit == null ? 200 : params.limit, 'limit'), 1000))
      const sinceId = params.sinceId == null ? 0 : int(params.sinceId, 'sinceId')
      const kind = params.kind ? String(params.kind) : null
      const level = params.level == null ? null : String(params.level)
      const filtered = logs.filter((x) =>
        x.id > sinceId &&
        (!kind || x.kind === kind) &&
        (!level || String(x.level) === level)
      )
      return {
        totalBuffered: logs.length,
        latestId: logs.length ? logs[logs.length - 1].id : 0,
        entries: filtered.slice(-limit)
      }
    }

    case 'clearConsoleLogs':
      logs.length = 0
      return { ok: true }

    case 'rendererEval': {
      const code = String(params.code || '')
      if (!code.trim()) throw new Error('code is required')
      if (code.length > 200000) throw new Error('code is too long')
      const depth = Math.max(0, Math.min(6, int(params.maxDepth == null ? 4 : params.maxDepth, 'maxDepth')))
      return inGame(`
        const __code = ${JSON.stringify(code)}
        const __AsyncFunction = Object.getPrototypeOf(async function(){}).constructor
        let __fn
        try {
          // Expression mode first: convenient for "S.state.store" and supports await.
          __fn = new __AsyncFunction('SMLN', 'S', '__mcpSanitize', 'return (' + __code + '\\n)')
        } catch (__syntax) {
          // Fall back to body mode for statements, declarations and explicit return.
          __fn = new __AsyncFunction('SMLN', 'S', '__mcpSanitize', __code)
        }
        let __value
        try {
          __value = await __fn.call(globalThis, S, S, __mcpSanitize)
        } catch (__e) {
          throw new Error((__e && __e.stack) || String(__e))
        }
        return __mcpSanitize(__value, ${depth})
      `, { ready: params.requireReady !== false })
    }

    case 'inspectDom': {
      const selector = String(params.selector || 'body')
      if (selector.length > 500) throw new Error('selector is too long')
      const limit = Math.max(1, Math.min(int(params.limit == null ? 20 : params.limit, 'limit'), 100))
      const html = !!params.html
      return inGame(`
        const nodes = Array.from(document.querySelectorAll(${JSON.stringify(selector)})).slice(0, ${limit})
        return nodes.map(function (el, index) {
          const r = el.getBoundingClientRect()
          const base = {
            index:index,
            tag:el.tagName,
            id:el.id || null,
            className:typeof el.className === 'string' ? el.className : null,
            text:(el.innerText || el.textContent || '').slice(0, 2000),
            rect:{x:r.x,y:r.y,width:r.width,height:r.height},
            visible:!!(r.width || r.height)
          }
          ${html ? "base.html = el.outerHTML.slice(0, 20000)" : ""}
          return base
        })
      `, { ready: false })
    }

    case 'stateKeys': {
      const rawPath = params.path == null ? '' : String(params.path)
      const parts = rawPath ? rawPath.split('.').filter(Boolean) : []
      for (const part of parts) safeName(part, 'path segment')
      return inGame(`
        let value = S.state
        for (const part of ${JSON.stringify(parts)}) {
          if (value == null) throw new Error('State path does not exist: ' + ${JSON.stringify(rawPath)})
          value = value[part]
        }
        if (value == null) return []
        return Object.keys(Object(value)).sort()
      `)
    }

    case 'inspectState': {
      const rawPath = params.path == null ? '' : String(params.path)
      if (rawPath.length > 1000) throw new Error('path is too long')
      const parts = rawPath ? rawPath.split('.').filter(Boolean) : []
      for (const part of parts) safeName(part, 'path segment')
      const maxDepth = Math.max(0, Math.min(6, int(params.maxDepth == null ? 3 : params.maxDepth, 'maxDepth')))
      return inGame(`
        let value = S.state
        for (const part of ${JSON.stringify(parts)}) {
          if (value == null) throw new Error('State path does not exist: ' + ${JSON.stringify(rawPath)})
          value = value[part]
        }
        return __mcpSanitize(value, ${maxDepth})
      `)
    }

    case 'cdpAttach': {
      const { wc } = await ensureCdp()
      return { ok: true, attached: wc.debugger.isAttached(), protocolVersion: '1.3' }
    }

    case 'cdpDetach': {
      const win = await findGameWindow()
      if (!win) throw new Error('game window not found')
      const wc = win.webContents
      if (wc.debugger.isAttached()) wc.debugger.detach()
      return { ok: true, attached: false }
    }

    case 'cdpCommand': {
      const methodName = safeName(params.method, 'method')
      const commandParams = params.params && typeof params.params === 'object' ? params.params : {}
      const sessionId = params.sessionId == null ? undefined : String(params.sessionId)
      const { wc } = await ensureCdp()
      const result = await wc.debugger.sendCommand(methodName, commandParams, sessionId)
      return result == null ? {} : result
    }

    case 'performanceSnapshot':
      return inGame(`
        const out = {
          performanceNow: performance.now(),
          timeOrigin: performance.timeOrigin,
          visibility: document.visibilityState,
          domNodes: document.getElementsByTagName('*').length,
          jsHeap: performance.memory ? {
            usedJSHeapSize: performance.memory.usedJSHeapSize,
            totalJSHeapSize: performance.memory.totalJSHeapSize,
            jsHeapSizeLimit: performance.memory.jsHeapSizeLimit
          } : null
        }
        try {
          out.playerPosition = S.game && S.game.player && S.game.player.getPosition
            ? __mcpSanitize(S.game.player.getPosition(S.state), 2) : null
        } catch (_) {}
        return out
      `, { ready: false })

    case 'listNamespaces':
      return inGame(`return Object.keys(S.game || {}).sort()`)

    case 'listMethods': {
      const ns = safeName(params.namespace, 'namespace')
      return inGame(`
        const obj = S.game[${JSON.stringify(ns)}]
        if (!obj) throw new Error('Unknown game API namespace: ' + ${JSON.stringify(ns)})
        const rows = []
        const seen = new Set()
        let cur = obj
        while (cur && cur !== Object.prototype) {
          for (const key of Object.getOwnPropertyNames(cur)) {
            if (key === 'constructor' || seen.has(key)) continue
            seen.add(key)
            let type = 'unknown'
            try { type = typeof obj[key] } catch (_) {}
            rows.push({name:key,type:type})
          }
          cur = Object.getPrototypeOf(cur)
        }
        return rows.sort((a,b)=>a.name.localeCompare(b.name))
      `)
    }

    case 'describeApi': {
      const ns = safeName(params.namespace, 'namespace')
      return inGame(`
        const obj = S.game[${JSON.stringify(ns)}]
        if (!obj) throw new Error('Unknown game API namespace: ' + ${JSON.stringify(ns)})
        const out = {}
        for (const key of Object.keys(obj)) {
          try {
            const v = obj[key]
            out[key] = typeof v === 'function'
              ? {type:'function', name:v.name || key, length:v.length, source:String(v).slice(0, 2000)}
              : {type:typeof v, value:__mcpSanitize(v, 2)}
          } catch (e) {
            out[key] = {error:String(e && e.message || e)}
          }
        }
        return out
      `)
    }

    case 'playerGetPosition':
      return inGame(`
        if (!S.game.player || typeof S.game.player.getPosition !== 'function') throw new Error('player.getPosition unavailable')
        return __mcpSanitize(S.game.player.getPosition(S.state), 3)
      `)

    case 'playerSetPosition': {
      const x = num(params.x, 'x'), y = num(params.y, 'y')
      return inGame(`
        if (!S.game.player || typeof S.game.player.setPosition !== 'function') throw new Error('player.setPosition unavailable')
        const value = S.game.player.setPosition(S.state, ${x}, ${y})
        try { S.refreshUI && S.refreshUI() } catch (_) {}
        return {ok:true,result:__mcpSanitize(await Promise.resolve(value),2)}
      `)
    }

    case 'getCellId': {
      const x = int(params.x, 'x'), y = int(params.y, 'y')
      return inGame(`
        if (!S.game.world || typeof S.game.world.getCellId !== 'function') throw new Error('world.getCellId unavailable')
        return S.game.world.getCellId(S.state, ${x}, ${y})
      `)
    }

    case 'createElement': {
      const x = int(params.x, 'x'), y = int(params.y, 'y'), id = int(params.id, 'id')
      const options = params.options && typeof params.options === 'object' ? params.options : {}
      return inGame(`
        if (!S.game.elements || typeof S.game.elements.createAt !== 'function') throw new Error('elements.createAt unavailable')
        return __mcpSanitize(await Promise.resolve(
          S.game.elements.createAt(S.state, ${x}, ${y}, ${id}, ${JSON.stringify(options)})
        ), 3)
      `)
    }

    case 'removeElement': {
      const x = int(params.x, 'x'), y = int(params.y, 'y')
      return inGame(`
        if (!S.game.elements || typeof S.game.elements.removeAt !== 'function') throw new Error('elements.removeAt unavailable')
        return __mcpSanitize(await Promise.resolve(S.game.elements.removeAt(S.state, ${x}, ${y})), 3)
      `)
    }

    case 'createTerrain': {
      const x = int(params.x, 'x'), y = int(params.y, 'y'), name = safeName(params.name, 'name')
      return inGame(`
        if (!S.game.terrains || typeof S.game.terrains.createAt !== 'function') throw new Error('terrains.createAt unavailable')
        return __mcpSanitize(await Promise.resolve(
          S.game.terrains.createAt(S.state, ${x}, ${y}, ${JSON.stringify(name)})
        ), 3)
      `)
    }

    case 'removeTerrain': {
      const x = int(params.x, 'x'), y = int(params.y, 'y')
      return inGame(`
        if (!S.game.terrains || typeof S.game.terrains.removeAt !== 'function') throw new Error('terrains.removeAt unavailable')
        return __mcpSanitize(await Promise.resolve(S.game.terrains.removeAt(S.state, ${x}, ${y})), 3)
      `)
    }

    case 'runConsoleCommand': {
      const command = safeName(params.command, 'command')
      const args = Array.isArray(params.args) ? params.args.map(String).slice(0, 64) : []
      return inGame(`
        const spec = S.commands && S.commands[${JSON.stringify(command)}]
        if (!spec || typeof spec.run !== 'function') throw new Error('Unknown SandLoader console command: ' + ${JSON.stringify(command)})
        return __mcpSanitize(await Promise.resolve(spec.run(${JSON.stringify(args)})), 4)
      `)
    }

    case 'callGameApi': {
      const namespace = safeName(params.namespace, 'namespace')
      const methodName = safeName(params.method, 'method')
      const args = Array.isArray(params.args) ? params.args : []
      if (args.length > 128) throw new Error('too many arguments')
      const stateFirst = params.stateFirst !== false
      return inGame(`
        const ns = S.game[${JSON.stringify(namespace)}]
        if (!ns) throw new Error('Unknown game API namespace: ' + ${JSON.stringify(namespace)})
        const fn = ns[${JSON.stringify(methodName)}]
        if (typeof fn !== 'function') throw new Error('Unknown game API method: ' + ${JSON.stringify(namespace + '.' + methodName)})
        const args = ${JSON.stringify(args)}
        const callArgs = ${stateFirst ? '[S.state].concat(args)' : 'args'}
        return __mcpSanitize(await Promise.resolve(fn.apply(ns, callArgs)), 4)
      `)
    }

    case 'sandloaderRpc': {
      const action = safeName(params.action, 'action')
      const payload = params.payload && typeof params.payload === 'object' ? params.payload : {}
      return inGame(`
        if (typeof S.callMain !== 'function') throw new Error('SMLN.callMain unavailable')
        return __mcpSanitize(await S.callMain(${JSON.stringify(action)}, ${JSON.stringify(payload)}), 6)
      `, { ready: false })
    }

    case 'getProblems':
      return inGame(`
        if (typeof S.callMain !== 'function') throw new Error('SMLN.callMain unavailable')
        return __mcpSanitize(await S.callMain('getProblems', {}), 6)
      `, { ready: false })

    case 'getMods':
      return inGame(`
        if (typeof S.callMain !== 'function') throw new Error('SMLN.callMain unavailable')
        return __mcpSanitize(await S.callMain('listMods', {}), 6)
      `, { ready: false })

    case 'getLoaderState':
      return inGame(`
        if (typeof S.callMain !== 'function') throw new Error('SMLN.callMain unavailable')
        return __mcpSanitize(await S.callMain('getLoaderState', {}), 6)
      `, { ready: false })

    case 'listLogFiles':
      return { directory: logDir(), files: listLogFiles() }

    case 'readLogTail':
      return readTail(params.file ? String(params.file) : null, params.maxBytes)

    case 'hostPaths':
      return {
        roots: scopedRoots(),
        hostPaths: hostApi && hostApi.paths ? hostApi.paths : null,
        install: smlnInfo && smlnInfo.install ? smlnInfo.install : null,
        mod: modInfo ? { id: modInfo.id, version: modInfo.version, dir: modInfo.dir } : null
      }

    case 'listScopedDir': {
      const root = safeName(params.root, 'root')
      return { root, entries: listScoped(root, params.path || '.', params.depth || 0) }
    }

    case 'readScopedFile': {
      const root = safeName(params.root, 'root')
      return readScoped(root, params.path || '', params.maxBytes)
    }

    case 'statScopedPath': {
      const rootName = safeName(params.root, 'root')
      const { root, target } = resolveScoped(rootName, params.path || '.')
      const st = fs.statSync(target)
      return {
        root: root.name,
        path: path.relative(root.path, target).split(path.sep).join('/'),
        type: st.isDirectory() ? 'dir' : st.isFile() ? 'file' : 'other',
        size: st.size,
        created: st.birthtime.toISOString(),
        modified: st.mtime.toISOString()
      }
    }

    case 'hashScopedFile': {
      const rootName = safeName(params.root, 'root')
      const { root, target } = resolveScoped(rootName, params.path || '')
      const st = fs.statSync(target)
      if (!st.isFile()) throw new Error('not a file')
      if (st.size > 128 * 1024 * 1024) throw new Error('file too large to hash through MCP')
      const algorithm = params.algorithm === 'sha1' ? 'sha1' : 'sha256'
      const digest = crypto.createHash(algorithm).update(fs.readFileSync(target)).digest('hex')
      return { root: root.name, path: path.relative(root.path, target).split(path.sep).join('/'), algorithm, digest, size: st.size }
    }

    case 'searchScopedText': {
      const rootName = safeName(params.root, 'root')
      return searchScoped(rootName, params.path || '.', params.query, params)
    }

    case 'systemMetrics':
      return {
        process: {
          pid: process.pid,
          uptime: process.uptime(),
          memoryUsage: process.memoryUsage(),
          resourceUsage: typeof process.resourceUsage === 'function' ? process.resourceUsage() : null,
          versions: process.versions
        },
        appMetrics: typeof app.getAppMetrics === 'function' ? app.getAppMetrics() : [],
        system: {
          platform: os.platform(),
          release: os.release(),
          arch: os.arch(),
          cpus: os.cpus().map((x) => ({ model: x.model, speed: x.speed })),
          totalmem: os.totalmem(),
          freemem: os.freemem(),
          loadavg: os.loadavg(),
          uptime: os.uptime()
        }
      }

    case 'webContentsInfo': {
      const win = await findGameWindow()
      if (!win) throw new Error('game window not found')
      const wc = win.webContents
      return {
        window: windowSummary(win),
        userAgent: wc.getUserAgent(),
        zoomFactor: wc.getZoomFactor(),
        zoomLevel: wc.getZoomLevel(),
        frameRate: typeof wc.getFrameRate === 'function' ? wc.getFrameRate() : null,
        backgroundThrottling: wc.getBackgroundThrottling ? wc.getBackgroundThrottling() : null,
        audioMuted: wc.isAudioMuted(),
        currentlyAudible: wc.isCurrentlyAudible ? wc.isCurrentlyAudible() : null
      }
    }

    case 'domComputedStyle': {
      const selector = String(params.selector || '')
      if (!selector) throw new Error('selector is required')
      const properties = Array.isArray(params.properties) ? params.properties.map(String).slice(0, 100) : []
      return inGame(`
        const el = document.querySelector(${JSON.stringify(selector)})
        if (!el) throw new Error('No element matches selector')
        const cs = getComputedStyle(el)
        const props = ${JSON.stringify(properties)}
        if (props.length) {
          const out = {}
          for (const p of props) out[p] = cs.getPropertyValue(p)
          return out
        }
        const out = {}
        for (let i = 0; i < cs.length && i < 500; i++) {
          const p = cs[i]
          out[p] = cs.getPropertyValue(p)
        }
        return out
      `, { ready: false })
    }

    case 'domClick': {
      const selector = String(params.selector || '')
      if (!selector) throw new Error('selector is required')
      return inGame(`
        const el = document.querySelector(${JSON.stringify(selector)})
        if (!el) throw new Error('No element matches selector')
        el.click()
        return { ok:true, tag:el.tagName, text:(el.innerText||el.textContent||'').slice(0,200) }
      `, { ready: false })
    }

    case 'domFocus': {
      const selector = String(params.selector || '')
      if (!selector) throw new Error('selector is required')
      return inGame(`
        const el = document.querySelector(${JSON.stringify(selector)})
        if (!el) throw new Error('No element matches selector')
        if (typeof el.focus === 'function') el.focus()
        return { ok:true, active:document.activeElement===el }
      `, { ready: false })
    }

    case 'domInput': {
      const selector = String(params.selector || '')
      const value = String(params.value == null ? '' : params.value)
      if (!selector) throw new Error('selector is required')
      return inGame(`
        const el = document.querySelector(${JSON.stringify(selector)})
        if (!el) throw new Error('No element matches selector')
        el.value = ${JSON.stringify(value)}
        el.dispatchEvent(new Event('input',{bubbles:true}))
        el.dispatchEvent(new Event('change',{bubbles:true}))
        return { ok:true, value:el.value }
      `, { ready: false })
    }

    case 'domAttributes': {
      const selector = String(params.selector || '')
      if (!selector) throw new Error('selector is required')
      return inGame(`
        const el = document.querySelector(${JSON.stringify(selector)})
        if (!el) throw new Error('No element matches selector')
        const attrs = {}
        for (const a of Array.from(el.attributes || [])) attrs[a.name] = a.value
        return attrs
      `, { ready: false })
    }

    case 'listConsoleCommands':
      return inGame(`
        return Object.keys(S.commands || {}).sort().map(function(name){
          const spec = S.commands[name] || {}
          return {name:name,summary:spec.summary||null,usage:spec.usage||null,args:__mcpSanitize(spec.args||[],3)}
        })
      `, { ready: false })

    case 'messagingStats':
      return inGame(`
        if (!S.messaging) return {available:false}
        return {
          available:true,
          targets:typeof S.messaging.targets==='function'?S.messaging.targets():null,
          stats:typeof S.messaging.stats==='function'?S.messaging.stats():null
        }
      `, { ready: false })

    case 'sendWorkerMessage': {
      const modID = safeName(params.modID || 'sandustry-mcp', 'modID')
      const channel = safeName(params.channel, 'channel')
      const args = Array.isArray(params.args) ? params.args : []
      return inGame(`
        if (!S.messaging || typeof S.messaging.sendWorkerMessage!=='function') throw new Error('SMLN.messaging unavailable')
        return __mcpSanitize(S.messaging.sendWorkerMessage(${JSON.stringify(modID)},${JSON.stringify(channel)},...${JSON.stringify(args)}),4)
      `)
    }

    case 'sendManagerMessage': {
      const modID = safeName(params.modID || 'sandustry-mcp', 'modID')
      const channel = safeName(params.channel, 'channel')
      const args = Array.isArray(params.args) ? params.args : []
      return inGame(`
        if (!S.messaging || typeof S.messaging.sendManagerMessage!=='function') throw new Error('SMLN.messaging unavailable')
        return __mcpSanitize(S.messaging.sendManagerMessage(${JSON.stringify(modID)},${JSON.stringify(channel)},...${JSON.stringify(args)}),4)
      `)
    }

    case 'enumKeys': {
      const table = params.table == null ? null : safeName(params.table, 'table')
      return inGame(`
        const E = S.enums || {}
        if (${JSON.stringify(table)} == null) return Object.keys(E).sort()
        const v = E[${JSON.stringify(table)}]
        if (v == null) throw new Error('unknown enum table')
        return Array.isArray(v) ? v.slice(0,5000) : Object.keys(Object(v)).sort().slice(0,5000)
      `, { ready: false })
    }

    case 'enumGet': {
      const table = safeName(params.table, 'table')
      const key = String(params.key)
      return inGame(`
        const v = (S.enums||{})[${JSON.stringify(table)}]
        if (v == null) throw new Error('unknown enum table')
        return __mcpSanitize(v[${JSON.stringify(key)}],4)
      `, { ready: false })
    }

    case 'captureStateSnapshot': {
      const label = String(params.label || ('snapshot-' + (snapshotSeq + 1)))
      const rawPath = params.path == null ? '' : String(params.path)
      const parts = rawPath ? rawPath.split('.').filter(Boolean) : []
      const maxDepth = Math.max(0, Math.min(8, int(params.maxDepth == null ? 5 : params.maxDepth, 'maxDepth')))
      const value = await inGame(`
        let value = S.state
        for (const part of ${JSON.stringify(parts)}) {
          if (value == null) throw new Error('State path does not exist')
          value = value[part]
        }
        return __mcpSanitize(value, ${maxDepth})
      `)
      const id = 's' + (++snapshotSeq)
      stateSnapshots.set(id, { id, label, path: rawPath, capturedAt: new Date().toISOString(), value: safeJsonClone(value) })
      while (stateSnapshots.size > 50) stateSnapshots.delete(stateSnapshots.keys().next().value)
      return { id, label, path: rawPath }
    }

    case 'listStateSnapshots':
      return Array.from(stateSnapshots.values()).map((x) => ({ id:x.id,label:x.label,path:x.path,capturedAt:x.capturedAt }))

    case 'getStateSnapshot': {
      const snap = stateSnapshots.get(String(params.id || ''))
      if (!snap) throw new Error('snapshot not found')
      return snap
    }

    case 'diffStateSnapshots': {
      const a = stateSnapshots.get(String(params.before || ''))
      const b = stateSnapshots.get(String(params.after || ''))
      if (!a || !b) throw new Error('snapshot not found')
      const limit = Math.max(1, Math.min(int(params.limit == null ? 500 : params.limit, 'limit'), 5000))
      const changes = []
      deepDiff(a.value, b.value, '$', changes, limit)
      return { before:{id:a.id,label:a.label}, after:{id:b.id,label:b.label}, changes, truncated:changes.length>=limit }
    }

    case 'clearStateSnapshots':
      stateSnapshots.clear()
      return { ok:true }

    case 'startEventProbe': {
      const eventName = safeName(params.event, 'event')
      const probeId = 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2,7)
      const limit = Math.max(1, Math.min(int(params.limit == null ? 500 : params.limit, 'limit'), 5000))
      return inGame(`
        globalThis.__SMLN_MCP_DEBUG__ = globalThis.__SMLN_MCP_DEBUG__ || {probes:{}}
        const D = globalThis.__SMLN_MCP_DEBUG__
        if (!S.game.events || typeof S.game.events.on !== 'function') throw new Error('FH.events.on unavailable')
        const rec = {id:${JSON.stringify(probeId)},event:${JSON.stringify(eventName)},createdAt:Date.now(),events:[],limit:${limit},off:null}
        const handler = function(payload){
          rec.events.push({ts:Date.now(),payload:__mcpSanitize(payload,4)})
          if (rec.events.length > rec.limit) rec.events.splice(0,rec.events.length-rec.limit)
        }
        const off = S.game.events.on(S.state,${JSON.stringify(eventName)},handler)
        if (typeof off === 'function') rec.off = off
        D.probes[rec.id] = rec
        return {id:rec.id,event:rec.event,limit:rec.limit}
      `)
    }

    case 'getEventProbe': {
      const id = safeName(params.id, 'id')
      const clear = !!params.clear
      return inGame(`
        const D = globalThis.__SMLN_MCP_DEBUG__
        const rec = D && D.probes && D.probes[${JSON.stringify(id)}]
        if (!rec) throw new Error('probe not found')
        const out = {id:rec.id,event:rec.event,createdAt:rec.createdAt,events:rec.events.slice()}
        if (${clear}) rec.events.length=0
        return out
      `)
    }

    case 'stopEventProbe': {
      const id = safeName(params.id, 'id')
      return inGame(`
        const D = globalThis.__SMLN_MCP_DEBUG__
        const rec = D && D.probes && D.probes[${JSON.stringify(id)}]
        if (!rec) throw new Error('probe not found')
        try { if (typeof rec.off==='function') rec.off() } catch(_){}
        delete D.probes[${JSON.stringify(id)}]
        return {ok:true,id:${JSON.stringify(id)}}
      `)
    }

    case 'listEventProbes':
      return inGame(`
        const D = globalThis.__SMLN_MCP_DEBUG__
        return Object.values((D&&D.probes)||{}).map(function(rec){
          return {id:rec.id,event:rec.event,createdAt:rec.createdAt,count:rec.events.length,limit:rec.limit}
        })
      `, { ready:false })

    case 'getModDetails':
      return inGame(`return __mcpSanitize(await S.callMain('getModDetails',{id:${JSON.stringify(String(params.id || ''))}}),6)`, {ready:false})

    case 'getModConfig':
      return inGame(`return __mcpSanitize(await S.callMain('getModConfig',{id:${JSON.stringify(String(params.id || ''))}}),6)`, {ready:false})

    case 'setModConfig': {
      const id = safeName(params.id,'id')
      const key = safeName(params.key,'key')
      return inGame(`return __mcpSanitize(await S.callMain('setModConfig',{id:${JSON.stringify(id)},key:${JSON.stringify(key)},value:${JSON.stringify(params.value)}}),6)`, {ready:false})
    }

    case 'resetModConfig': {
      const id = safeName(params.id,'id')
      const payload = {id}
      if (params.key != null) payload.key = String(params.key)
      return inGame(`return __mcpSanitize(await S.callMain('resetModConfig',${JSON.stringify(payload)}),6)`, {ready:false})
    }

    case 'rescanAnchors':
      return inGame(`return __mcpSanitize(await S.callMain('rescanAnchors',{}),7)`, {ready:false})

    case 'reloadModsPlan':
      return inGame(`return __mcpSanitize(await S.callMain('reloadMods',{plan:true,apply:false}),6)`, {ready:false})

    case 'reloadModsApply':
      return inGame(`return __mcpSanitize(await S.callMain('reloadMods',{apply:true}),6)`, {ready:false})

    case 'reloadOneMod': {
      const id = safeName(params.id,'id')
      return inGame(`return __mcpSanitize(await S.callMain('reloadMod',{id:${JSON.stringify(id)}}),6)`, {ready:false})
    }

    case 'stateArrayPage': {
      const rawPath = String(params.path || '')
      if (!rawPath) throw new Error('path is required')
      const parts = rawPath.split('.').filter(Boolean)
      for (const part of parts) safeName(part, 'path segment')
      const offset = Math.max(0, int(params.offset == null ? 0 : params.offset, 'offset'))
      const limit = Math.max(1, Math.min(int(params.limit == null ? 50 : params.limit, 'limit'), 500))
      return inGame(`
        let arr = S.state
        for (const part of ${JSON.stringify(parts)}) {
          if (arr == null) throw new Error('State path does not exist: ' + ${JSON.stringify(rawPath)})
          arr = arr[part]
        }
        if (!Array.isArray(arr)) throw new Error('State path is not an array: ' + ${JSON.stringify(rawPath)})
        function compact(v, index) {
          if (v == null || typeof v !== 'object') return {index:index,value:v}
          const out = {index:index}
          const preferred = ['id','ID','uid','uuid','type','kind','name','key','x','y','z','width','height','rotation','angle','elementId','elementID','structureId','projectileId','ownerId','team','state','status','active','enabled']
          const used = new Set()
          for (const k of preferred) {
            if (!Object.prototype.hasOwnProperty.call(v,k)) continue
            const val = v[k]
            if (val == null || ['string','number','boolean'].includes(typeof val)) { out[k]=val; used.add(k) }
          }
          let added = 0
          for (const k of Object.keys(v)) {
            if (used.has(k) || added >= 20) continue
            const val = v[k]
            if (val == null || ['string','number','boolean'].includes(typeof val)) {
              out[k]=val
              added++
            }
          }
          out.__keys = Object.keys(v).length
          return out
        }
        const end = Math.min(arr.length, ${offset} + ${limit})
        const items = []
        for (let i=${offset}; i<end; i++) items.push(compact(arr[i],i))
        return {path:${JSON.stringify(rawPath)},total:arr.length,offset:${offset},limit:${limit},nextOffset:end<arr.length?end:null,items:items}
      `)
    }

    case 'stateArrayItem': {
      const rawPath = String(params.path || '')
      if (!rawPath) throw new Error('path is required')
      const parts = rawPath.split('.').filter(Boolean)
      for (const part of parts) safeName(part, 'path segment')
      const index = int(params.index, 'index')
      const maxDepth = Math.max(0, Math.min(10, int(params.maxDepth == null ? 8 : params.maxDepth, 'maxDepth')))
      return inGame(`
        let arr = S.state
        for (const part of ${JSON.stringify(parts)}) {
          if (arr == null) throw new Error('State path does not exist')
          arr = arr[part]
        }
        if (!Array.isArray(arr)) throw new Error('State path is not an array')
        if (${index} < 0 || ${index} >= arr.length) throw new Error('index out of range')
        return {path:${JSON.stringify(rawPath)},index:${index},total:arr.length,item:__mcpSanitize(arr[${index}],${maxDepth})}
      `)
    }

    case 'searchStateArray': {
      const rawPath = String(params.path || '')
      const query = String(params.query == null ? '' : params.query)
      if (!rawPath) throw new Error('path is required')
      if (!query) throw new Error('query is required')
      const parts = rawPath.split('.').filter(Boolean)
      for (const part of parts) safeName(part, 'path segment')
      const maxResults = Math.max(1, Math.min(int(params.maxResults == null ? 100 : params.maxResults, 'maxResults'), 1000))
      const caseSensitive = !!params.caseSensitive
      return inGame(`
        let arr = S.state
        for (const part of ${JSON.stringify(parts)}) {
          if (arr == null) throw new Error('State path does not exist')
          arr = arr[part]
        }
        if (!Array.isArray(arr)) throw new Error('State path is not an array')
        const q0 = ${JSON.stringify(query)}
        const q = ${caseSensitive} ? q0 : q0.toLowerCase()
        function scalarString(v){ return v == null ? String(v) : String(v) }
        function compact(v,index){
          if (v == null || typeof v !== 'object') return {index:index,value:v}
          const out={index:index}
          const preferred=['id','ID','uid','uuid','type','kind','name','key','x','y','z','rotation','elementId','elementID','structureId','projectileId','ownerId','team','state','status']
          for(const k of preferred){
            if(!Object.prototype.hasOwnProperty.call(v,k)) continue
            const val=v[k]
            if(val==null||['string','number','boolean'].includes(typeof val)) out[k]=val
          }
          let added=0
          for(const k of Object.keys(v)){
            if(k in out||added>=20) continue
            const val=v[k]
            if(val==null||['string','number','boolean'].includes(typeof val)){out[k]=val;added++}
          }
          return out
        }
        const hits=[]
        for(let i=0;i<arr.length && hits.length<${maxResults};i++){
          const v=arr[i]
          let matched=false
          if(v==null||typeof v!=='object'){
            const sv=scalarString(v); matched=(${caseSensitive}?sv:sv.toLowerCase()).includes(q)
          }else{
            for(const k of Object.keys(v)){
              const val=v[k]
              if(val!=null && ['string','number','boolean'].includes(typeof val)){
                const candidate=k+'='+scalarString(val)
                if((${caseSensitive}?candidate:candidate.toLowerCase()).includes(q)){matched=true;break}
              }
            }
          }
          if(matched) hits.push(compact(v,i))
        }
        return {path:${JSON.stringify(rawPath)},query:q0,total:arr.length,maxResults:${maxResults},hits:hits,truncated:hits.length>=${maxResults}}
      `)
    }

    default:
      throw new Error('Unknown bridge method: ' + method)
  }
}

function write(socket, value) {
  try { socket.write(JSON.stringify(value) + '\n') } catch (_) {}
}

function onConnection(socket) {
  const remote = socket.remoteAddress
  if (remote !== '127.0.0.1' && remote !== '::ffff:127.0.0.1') {
    socket.destroy()
    return
  }
  socket.setEncoding('utf8')
  let buffer = ''
  socket.on('data', (chunk) => {
    buffer += chunk
    if (buffer.length > MAX_LINE) {
      write(socket, { id: null, ok: false, error: 'request too large' })
      socket.destroy()
      return
    }
    let nl
    while ((nl = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, nl).trim()
      buffer = buffer.slice(nl + 1)
      if (!line) continue
      let req
      try { req = JSON.parse(line) }
      catch (_) { write(socket, { id: null, ok: false, error: 'invalid JSON' }); continue }
      Promise.resolve(handle(req.method, req.params))
        .then((result) => write(socket, { id: req.id, ok: true, result }))
        .catch((error) => write(socket, {
          id: req.id, ok: false, error: String(error && error.stack || error)
        }))
    }
  })
  socket.on('error', () => {})
}


function httpJson(res, status, value) {
  const body = JSON.stringify(value, null, 2)
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  })
  res.end(body)
}

function httpText(res, status, body, type) {
  res.writeHead(status, {
    'Content-Type': (type || 'text/plain') + '; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  })
  res.end(body)
}

function isAllowedOrigin(req) {
  const origin = req.headers.origin
  if (!origin) return true
  return origin === `http://${HOST}:${HTTP_PORT}` ||
         origin === `http://localhost:${HTTP_PORT}`
}

function readHttpJson(req) {
  return new Promise((resolve, reject) => {
    let data = ''
    req.setEncoding('utf8')
    req.on('data', (chunk) => {
      data += chunk
      if (data.length > MAX_LINE) {
        reject(new Error('request body too large'))
        req.destroy()
      }
    })
    req.on('end', () => {
      if (!data.trim()) return resolve({})
      try { resolve(JSON.parse(data)) }
      catch (_) { reject(new Error('invalid JSON body')) }
    })
    req.on('error', reject)
  })
}

function loadDebugPage() {
  const file = path.join(__dirname, 'dashboard.html')
  try {
    return fs.readFileSync(file, 'utf8')
  } catch (e) {
    return '<!doctype html><meta charset="utf-8"><title>Sandustry MCP Debug</title><pre>dashboard.html could not be loaded: ' +
      String(e && e.message || e).replace(/[&<>]/g, '') + '</pre>'
  }
}


async function onHttpRequest(req, res) {
  const remote = req.socket && req.socket.remoteAddress
  if (remote !== '127.0.0.1' && remote !== '::ffff:127.0.0.1' && remote !== '::1') {
    httpJson(res, 403, { ok:false, error:'loopback only' })
    return
  }

  if (!isAllowedOrigin(req)) {
    httpJson(res, 403, { ok:false, error:'cross-origin browser requests are not allowed' })
    return
  }

  const url = new URL(req.url || '/', `http://${HOST}:${HTTP_PORT}`)

  if (req.method === 'GET' && url.pathname === '/') {
    httpText(res, 200, loadDebugPage(), 'text/html')
    return
  }

  if (req.method === 'GET' && url.pathname === '/api/status') {
    try {
      httpJson(res, 200, { ok:true, result:await handle('status', {}) })
    } catch (e) {
      httpJson(res, 500, { ok:false, error:String(e && e.stack || e) })
    }
    return
  }

  if (req.method === 'GET' && url.pathname === '/api/health') {
    httpJson(res, 200, { ok:true, service:'sandustry-mcp-debug', version:'2.3.0', tcpPort:PORT, httpPort:HTTP_PORT })
    return
  }

  if (req.method === 'GET' && url.pathname === '/api/tools') {
    try {
      const catalog = JSON.parse(fs.readFileSync(path.join(__dirname, 'tool-catalog.json'), 'utf8'))
      httpJson(res, 200, { ok:true, tools:catalog })
    } catch (e) {
      httpJson(res, 500, { ok:false, error:String(e && e.stack || e) })
    }
    return
  }

  if (req.method === 'POST' && url.pathname === '/api/call') {
    const contentType = String(req.headers['content-type'] || '').toLowerCase()
    if (!contentType.startsWith('application/json')) {
      httpJson(res, 415, { ok:false, error:'Content-Type must be application/json' })
      return
    }
    try {
      const body = await readHttpJson(req)
      if (!body || typeof body.method !== 'string' || !body.method) {
        httpJson(res, 400, { ok:false, error:'body.method is required' })
        return
      }
      const result = await handle(body.method, body.params || {})
      httpJson(res, 200, { ok:true, result })
    } catch (e) {
      httpJson(res, 500, { ok:false, error:String(e && e.stack || e) })
    }
    return
  }

  httpJson(res, 404, {
    ok:false,
    error:'not found',
    routes:[
      'GET /',
      'GET /api/health',
      'GET /api/status',
      'GET /api/tools',
      'POST /api/call'
    ]
  })
}

function startHttpServer() {
  httpServer = http.createServer((req, res) => {
    Promise.resolve(onHttpRequest(req, res)).catch((e) => {
      try { httpJson(res, 500, { ok:false, error:String(e && e.stack || e) }) } catch (_) {}
    })
  })
  httpServer.on('error', (error) => {
    if (error && error.code === 'EADDRINUSE') log('warn', `MCP HTTP debug port ${HTTP_PORT} already in use`)
    else log('error', 'MCP HTTP debug server error: ' + String(error && error.stack || error))
  })
  httpServer.listen({ host:HOST, port:HTTP_PORT, exclusive:true }, () => {
    log('info', `MCP HTTP debug API v2.3.0 listening on http://${HOST}:${HTTP_PORT}/`)
  })
}

module.exports.setup = ({ mod, logger, host, smln }) => {
  scopedLogger = logger
  hostApi = host
  modInfo = mod
  smlnInfo = smln

  hookAllWindows()
  try {
    app.on('browser-window-created', (_event, win) => hookWindow(win))
  } catch (_) {}

  server = net.createServer(onConnection)
  server.on('error', (error) => {
    if (error && error.code === 'EADDRINUSE') log('warn', `MCP debug bridge port ${PORT} already in use`)
    else log('error', 'MCP debug bridge error: ' + String(error && error.stack || error))
  })
  server.listen({ host: HOST, port: PORT, exclusive: true }, () => {
    log('info', `MCP debug bridge v2.3.0 listening on ${HOST}:${PORT}`)
  })

  startHttpServer()

  return { patches: [] }
}
