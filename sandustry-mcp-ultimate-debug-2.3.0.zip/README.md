# Sandustry MCP Ultimate Debug Bridge v2.3.0

A full local debugging bridge for Sandustry + SandLoader.

## Major areas

- Sandustry live state inspection and snapshots/diffs
- FH/SMLN API discovery and direct calls
- SandLoader mod/config/problem/anchor/reload diagnostics
- Renderer JavaScript execution
- DOM inspection and UI interaction
- Electron window/process diagnostics
- Chrome DevTools Protocol passthrough
- Console, crash, preload and load-error capture
- Worker messaging diagnostics
- Game event probes
- SandLoader log access
- Scoped game/SandLoader/mod file inspection and text search
- Screenshots
- System/process/performance metrics

## Full-power tools

`renderer_eval`, `sandloader_rpc`, and `cdp_command` are intentional debug escape
hatches. Together they allow a trusted local MCP client to inspect nearly any
part of the running renderer and SandLoader process.

The file tools are intentionally read-only and restricted to discovered
Sandustry/SandLoader/mod roots. They do not expose arbitrary host filesystem
paths.

## Install

1. SandLoader Mods -> Install mod from ZIP.
2. Select this ZIP.
3. Approve the native Node.js permission warning.
4. Restart Sandustry.
5. Load a save.
6. Configure the MCP client to run `mcp-server.js`.

Example:

```json
{
  "mcpServers": {
    "sandustry": {
      "command": "node",
      "args": ["C:\\path\\to\\sandustry-mcp-debug-v2\\mcp-server.js"]
    }
  }
}
```

## Security

The native bridge binds only to `127.0.0.1:47651` and rejects non-loopback
connections. Do not port-forward that port.

This mod has native Node privileges once you approve it. Only use it for local,
trusted debugging.


## Browser HTTP API

v2.3.0 adds a real local HTTP interface on:

`http://127.0.0.1:47652/`

Open that URL directly in Chrome. The page includes a small status/debug UI.

Examples:

```js
fetch('/api/status')
  .then(r => r.json())
  .then(console.log)
```

Generic bridge call:

```js
fetch('/api/call', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    method: 'inspectState',
    params: {path: 'store.player', maxDepth: 4}
  })
}).then(r => r.json()).then(console.log)
```

The HTTP API accepts only loopback connections and rejects cross-origin browser
requests. Use the console on the page served from `127.0.0.1:47652`, not a
random website.


## English live dashboard

Open:

`http://127.0.0.1:47652/`

The bundled `dashboard.html` provides a live English dashboard with configurable
refresh intervals. It displays:

- bridge/game readiness
- Renderer/WebContents status
- Node/Electron/system metrics
- renderer performance and JS heap
- SandLoader Problems
- installed mods and loader state
- SandLoader log files and live log tail
- player position
- worker messaging statistics
- game API namespaces
- developer-console commands
- enum/reference tables
- renderer/Electron console and crash events
- arbitrary dotted `SMLN.state` inspection
- state key browsing
- game API namespace inspection
- generic bridge read calls
- one combined raw-data view

The dashboard is bundled inside the mod ZIP and requires no external web files.


## v2.3.0

- Large-array explorer for structures, projectiles and any other `SMLN.state` array.
- Compact rows expose primitive identifiers and fields instead of collapsing every entry to `[Object]`.
- Pagination up to 500 entities per page.
- Search by ID, type, name, coordinates or any primitive field.
- Click a row to inspect the complete item with deep expansion.
- Bundled AI Tool Catalog showing every exposed MCP tool, its description, JSON schema,
  ready-to-copy MCP `tools/call` request, and browser HTTP equivalent.
- Exact tool catalog is served at `GET /api/tools`.

Current MCP tool count in this build: 73.
